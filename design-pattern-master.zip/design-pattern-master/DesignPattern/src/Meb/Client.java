package Meb;

/**
 * 中介者模式 （中介很黑。。。）
 */
public class Client {
    public static void main(String[] args) {

        AbstractChatroom HappyChat=new ChatGroup();
        Member member1,member2,member3,member4,member5;
        member1=new DiamondMember("大");
        member2=new DiamondMember("二");
        member3=new CommonMember ("三");
        member4=new CommonMember ("四");
        member5=new CommonMember ("五");

        HappyChat.register(member1);
        HappyChat.register(member2);
        HappyChat.register(member3);
        HappyChat.register(member4);
        HappyChat.register(member5);

        member1.sendText("三","How are you?");
        member3.sendText("大","I am fine,think you and you?");
        member2.sendImage("四","GIF表情");
        member5.sendImage("二","表情包");
    }
}
