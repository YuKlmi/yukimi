package ABF;

abstract class AConF implements AFruitAndVegetables {

    @Override
    public Fruit createF() {
        return new Apple();
    }

}
