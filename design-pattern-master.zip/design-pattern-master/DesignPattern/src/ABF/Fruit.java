package ABF;

public class Fruit {

    public void eat(){

    }

}
