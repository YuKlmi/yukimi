package ABF;

abstract class BConV implements BFruitAndVegetables {

    @Override
    public Vegetables createV() {
        return new Tomato();
    }
}
