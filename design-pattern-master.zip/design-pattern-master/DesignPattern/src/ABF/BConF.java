package ABF;

abstract class BConF implements BFruitAndVegetables {

    @Override
    public Fruit createF() {
        return new Banana();
    }
}
