package ABF;

public interface BFruitAndVegetables {
    public Fruit createF();
    public Vegetables createV();
}
