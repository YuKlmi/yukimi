package ABF;

public class Vegetables {
    public void eat(){

    }
}
