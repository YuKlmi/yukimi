package ABF;

public interface AFruitAndVegetables {
    public Fruit createF();
    public Vegetables createV();
}
