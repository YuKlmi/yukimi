package ABF;

abstract class AConV implements AFruitAndVegetables {

    @Override
    public Vegetables createV() {
        return null;
    }
}
