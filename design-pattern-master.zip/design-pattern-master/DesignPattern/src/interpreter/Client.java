package interpreter;

/**
 * 解释器模式
 */
public class Client {

    public static void main(String[] args) {
        Expression isMale = getMaleExpression();
        Expression isMarriedWoman = getMarriedWomanExpression();
        System.out.println("John is male? " + isMale.interpret("RobertJohn"));
        System.out.println("Julie is a married woman? " + isMarriedWoman.interpret("Julie"));
    }


    public static Expression getMaleExpression() {
        Expression robert =new TerminalExpression("Robert");
        Expression john = new TerminalExpression("John");
        return new AndExpression(robert, john);
    }

    public static Expression getMarriedWomanExpression() {
        Expression julie =new TerminalExpression("Julie");
        Expression married = new TerminalExpression("married");
        return new OrExpression(julie, married);
    }

}
