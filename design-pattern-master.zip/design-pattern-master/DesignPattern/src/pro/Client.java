package pro;

/**
 * 原型&单例 模式
 */
public class Client {
    public static void main(String[] args) {
//        MyFruit fru1=new Apple();
//        MyFruit fru2=(Apple)fru1.clone();
//        fru1.display();
//        fru2.display();
//        System.out.println("fru1:"+fru1.hashCode());
//        System.out.println("fru2:"+fru2.hashCode());

        MyFruit fru1 = new Apple();
        MyFruit fru2 = new Banana();

        MyFruitStore mfs1=MyFruitStore.getFruitStore();

        mfs1.add(1, fru1);
        mfs1.add(2, fru2);
        mfs1.add(3, new Apple());
        mfs1.add(4, new Banana());
        MyFruitStore mfs2=MyFruitStore.getFruitStore();

        MyFruit fru=(MyFruit)mfs1.get(3);
        fru.display();
        System.out.println("mfs1"+mfs1.toString());
        System.out.println("mfs2"+mfs2.toString());
    }
}
