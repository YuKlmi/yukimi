package pro;

public class MyFruit implements Cloneable{
    protected String kind;

    public void display() {
        System.out.println(kind);
    }

    public Object clone(){
        Object obj = null;
        try {
            obj=super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
        return obj;
    }

    public String getKind() {
        return kind;
    }
}
