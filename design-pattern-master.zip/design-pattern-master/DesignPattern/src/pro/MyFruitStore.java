package pro;

import java.util.Hashtable;

public class MyFruitStore {
    private static Hashtable fruitTable=null;
    private static MyFruitStore fruitStore=null;

    private MyFruitStore(){
        fruitTable=new Hashtable<Integer,MyFruit>();
    }

    /**
     * 私有化 构造方法 使得 只能再自己的类中 调用
     * getFruitStore方法 调用 构造方法 为空则构造 ，不为空则返回已有的 实例对象 ，保证 只有一个水果店实例对象
     * （单例）
     */
    public static MyFruitStore getFruitStore(){
        if(fruitStore==null){
            fruitStore=new MyFruitStore();
        }
        return fruitStore;
    }

    public void add(Integer key,MyFruit fruit){
        fruitTable.put(key,fruit);
    }

    /**
     * key：货架号 ，对应一种水果
     * get方法 得到的实际是原来水果对象的克隆（原型模式）
     */
    public MyFruit get(Integer key){
        MyFruit fruit=(MyFruit)fruitTable.get(key);
        return (MyFruit)fruit.clone();
    }
}
