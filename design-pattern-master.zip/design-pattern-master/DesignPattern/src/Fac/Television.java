package Fac;

public class Television {
    public void on() {
        System.out.println("开电视");
    }

    public void off() {
        System.out.println("关电视");
    }
}
