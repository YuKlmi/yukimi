package Fac;

public class AirConditioner {
    public void on() {
        System.out.println("空调 开！");
    }

    public void off() {
        System.out.println("空调 关");
    }
}
