package Fac;

public class Light {
    private String position;

    public Light(String position) {
        this.position = position;
    }

    public void on() {
        System.out.println(this.position+"老灯打开了");
    }

    public void off() {
        System.out.println(this.position+"老灯被关了");
    }
}
