package Bui;


public class MealBuilder extends Meal{
    public Meal meal=new Meal();
    public void buildFood() {}
    public void buildDrink() {}
    public Meal getMeal() {
        return meal;
    }
}
