package Bui;

public class KFCWaiter {
    private MealBuilder mb;

    /**
     * setMealBuilder：服务员 获得套餐
     * construct：服务员 开始做饭
     */
    public void setMealBuilder(MealBuilder mb) {
        this.mb = mb;
    }
    public Meal construct() {
        mb.buildFood();
        mb.buildDrink();
        return mb.getMeal();
    }

}
