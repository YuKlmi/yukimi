package Com;

public class Pear extends MyElement{
    @Override
    public void eat(){
        System.out.println("梨子我炫炫炫！");
    }
}
