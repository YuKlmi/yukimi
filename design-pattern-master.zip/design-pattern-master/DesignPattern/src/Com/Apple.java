package Com;

public class Apple extends MyElement{
    @Override
    public void eat(){
        System.out.println("苹果我炫！");
    }
}
