package Com;

public class Banana extends MyElement{
    @Override
    public void eat(){
        System.out.println("香蕉我炫！");
    }
}
