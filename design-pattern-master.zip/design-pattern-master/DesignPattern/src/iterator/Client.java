package iterator;

public class Client {

    public static void display(Television tv) {
        TVIterator i=tv.createIterator();
        System.out.println("电视频道：");
        while(!i.isLast()){
            System.out.println(i.currentChannel());
            i.next();
        }
    }

    public static void main(String[] args) {
        Television tv=(Television)XMLUtil.getBean();  //创造一个电视
        display(tv);                                  //用迭代器 输出 所有电视节目
    }

}
