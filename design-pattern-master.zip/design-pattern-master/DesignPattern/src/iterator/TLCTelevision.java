package iterator;

public class TLCTelevision implements Television{

    private Object[] obj={"TLC:CCTV-1","TLC:CCTV-2","TLC:CCTV-3","TLC:CCTV-4","TLC:CCTV-5","TLC:CCTV-6","TLC:CCTV-7","TLC:CCTV-8"};

    @Override
    public TVIterator createIterator() {
        return new TLCIterator();
    }

    private class TLCIterator implements TVIterator {

        private int currentIndex=0;

        @Override
        public void next() {
            if(currentIndex<obj.length){
                currentIndex++;
            }
        }

        @Override
        public void previous() {
            if(currentIndex>0){
                currentIndex--;
            }
        }

        @Override
        public void setChannel(int i){
            currentIndex=i;
        }

        @Override
        public Object currentChannel() {
            return obj[currentIndex];
        }

        @Override
        public boolean isFirst(){
            return currentIndex==0;
        }

        @Override
        public boolean isLast(){
            return currentIndex==obj.length;
        }

    }

}
