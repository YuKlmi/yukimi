package iterator;

public interface TVIterator {
    void setChannel(int i);
    void next();
    void previous();
    boolean isLast();
    boolean isFirst();
    Object currentChannel();

}
