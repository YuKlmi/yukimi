package iterator;

public class SkyworthTelevision implements Television {

    private Object[] obj={"Skyworth:CCTV-1","Skyworth:CCTV-2","Skyworth:CCTV-3","Skyworth:CCTV-4","Skyworth:CCTV-5","Skyworth:CCTV-6","Skyworth:CCTV-7","Skyworth:CCTV-8"};

    @Override
    public TVIterator createIterator() {
        return new SkyworthIterator();
    }
    private class SkyworthIterator implements TVIterator {

        private int currentIndex=0;

        @Override
        public void next() {
            if(currentIndex<obj.length){
                currentIndex++;
            }
        }

        @Override
        public void previous() {
            if(currentIndex>0){
                currentIndex--;
            }
        }

        @Override
        public void setChannel(int i){
            currentIndex=i;
        }

        @Override
        public Object currentChannel() {
            return obj[currentIndex];
        }

        @Override
        public boolean isFirst(){
            return currentIndex==0;
        }

        @Override
        public boolean isLast(){
            return currentIndex==obj.length;
        }

    }
}
