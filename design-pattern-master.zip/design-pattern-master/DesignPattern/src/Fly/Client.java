package Fly;

import java.util.Random;

public class Client {
    public static void main(String[] args) {
        Random rm=new Random();
        PieceFactory pFactory=new PieceFactory();
        for(int i=1;i<=19;i++){
            for(int j=1;j<=19;j++){
                APiece p;
                if(rm.nextInt()%2==0){
                    p=pFactory.getPiece("白棋");
                }else{
                    p=pFactory.getPiece("黑棋");
                }
                p.play(rm.nextInt(19),rm.nextInt(19));
            }
        }
        System.out.println("总共棋子对象个数是："+pFactory.getPieceCount());
    }
}
