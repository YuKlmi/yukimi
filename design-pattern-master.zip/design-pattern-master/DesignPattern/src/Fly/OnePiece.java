package Fly;

public class OnePiece extends APiece{

    public OnePiece(String inKind){
        super(inKind);
    }

    @Override
    public void play(int x, int y) {
        System.out.println(inKind+"落在("+x+","+y+")");
    }
}
