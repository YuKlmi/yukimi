package Fly;

import java.util.HashMap;

public class PieceFactory {
    private HashMap PiecePool=new HashMap();

    public APiece getPiece(String key){
        if(!PiecePool.containsKey(key)){
            APiece p=new OnePiece(key);
            PiecePool.put(key,p);
            return p;
        }
        return (APiece)PiecePool.get(key);
    }

    public int getPieceCount(){
        return PiecePool.size();
    }
}
