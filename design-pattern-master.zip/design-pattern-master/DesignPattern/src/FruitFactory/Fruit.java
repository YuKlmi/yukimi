package FruitFactory;

public class Fruit {

    public void eat(){

    }

}
