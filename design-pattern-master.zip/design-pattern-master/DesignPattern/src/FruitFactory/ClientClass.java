package FruitFactory;

public class ClientClass {
    public static void main(String[] args) {
        Factory factory = (Factory) XMLUtil.getBean();
        Fruit fruit= factory.CreateFruit();
        fruit.eat();
    }
}
