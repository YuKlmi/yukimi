package FruitFactory;

public class Factory {

    public Fruit CreateFruit() {

        return null;
    }
}
