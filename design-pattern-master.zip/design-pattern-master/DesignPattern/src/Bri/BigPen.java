package Bri;

public class BigPen extends Pen{
    public void draw(String name){
        String penType="大号🖊绘制";
        this.color.bepaint(penType,name);
    }
}
