package Bri;

public class White implements Color{
    public void bepaint(String penType,String name) {
        System.out.println(penType + "绿色的" + name);
    }
}
