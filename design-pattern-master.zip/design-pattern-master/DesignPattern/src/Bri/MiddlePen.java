package Bri;

public class MiddlePen extends Pen{
    public void draw(String name){
        String penType="中号笔绘制";
        this.color.bepaint(penType,name);
    }

}
