package Bri;

import java.io.File;
import org.w3c.dom.*;
import javax.xml.parsers.*;

public class XMLUtil {

    public static Object getBean(String kind){
        try{
            //创建文档对象
            DocumentBuilderFactory dFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = dFactory.newDocumentBuilder();
            Document doc = builder.parse(new File("src/bridging/config.xml"));

            //获取包含类名的文本节点
            NodeList n1 = doc.getElementsByTagName("className");
            Node classNode=null;
            if(kind.equals("color")){
                classNode = n1.item(0).getFirstChild();
            } else if (kind.equals("pen")) {
                classNode = n1.item(1).getFirstChild();
            }

            String cName = classNode.getNodeValue();

            //通过类名生成示例对象并返回
            Class c = Class.forName(cName);
            Object obj = c.newInstance();
            return obj;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }
}


