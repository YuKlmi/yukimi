package Ada;

import pro.Apple;
import pro.Banana;
import pro.MyFruit;
import pro.MyFruitStore;

/**
 * 适配器模式
 */
public class Client {
    public static void main(String[] args) {
        //创建商店
        MyFruit fru1 = new Apple();
        MyFruit fru2 = new Banana();
        MyFruitStore mfs=MyFruitStore.getFruitStore();
        mfs.add(1, fru1);
        mfs.add(2, fru2);


        InewOldJuicer newOldJuicer=new AdapterPort();
        System.out.println(newOldJuicer.newPort(mfs.get(1),mfs.get(2)));
    }
}
