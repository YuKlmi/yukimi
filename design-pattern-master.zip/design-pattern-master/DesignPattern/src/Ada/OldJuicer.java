package Ada;

import pro.MyFruit;

public class OldJuicer {

    public String onePort(MyFruit fruit) {
        String str=fruit.getKind()+"变成美汁汁";
        return str;
    }
}
