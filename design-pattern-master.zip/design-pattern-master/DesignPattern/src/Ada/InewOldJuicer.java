package Ada;

import pro.MyFruit;

public interface InewOldJuicer {
    public String newPort(MyFruit fruit1, MyFruit fruit2);
}
