package Ada;

import pro.MyFruit;

public class AdapterPort extends OldJuicer implements InewOldJuicer {

    @Override
    public String newPort(MyFruit fruit1,MyFruit fruit2) {
        String str="混合美汁汁："+onePort(fruit1)+"＆"+onePort(fruit2);
        return str;
    }

}
