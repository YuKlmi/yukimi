package Dec;

public class Cake implements IBirthdayCake{
    public Cake(){
        System.out.println("Cake Blank was Created");
    }

    public void show(){
        System.out.println("Cake Blank");
    }
}
