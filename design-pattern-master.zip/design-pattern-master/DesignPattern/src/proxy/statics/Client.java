package proxy.statics;

public class Client {
    public static void main(String[] args) {
        IShowPic cls=new CLocalPicShow();
        cls.showPic("一个好图片");
    }
}
