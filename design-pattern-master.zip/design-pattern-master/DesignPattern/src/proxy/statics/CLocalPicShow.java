package proxy.statics;

//将远程图片加载为本地显示的类
public class CLocalPicShow implements IShowPic,Runnable{
    private IShowPic pic;
    private String picName;

    @Override
    public void run() {
        pic.showPic(picName);
        System.out.println(picName+"：远程图片调用完成");
    }

    @Override
    public void showPic(String picName) {
        pic=new CRemoPic();
        this.picName=picName;
        System.out.println("准备载入远程图片："+picName);
        Thread th=new Thread(this);
        th.start();
    }

}
