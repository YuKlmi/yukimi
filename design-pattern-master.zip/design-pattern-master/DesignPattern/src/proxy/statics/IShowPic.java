package proxy.statics;

public interface IShowPic {
    void showPic(String picName);
}
