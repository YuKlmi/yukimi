package proxy.dynamics;

public class Client {
    public static void main(String[] args) {
//        IShowPic isp = new CRemoPic();
//        CLocalPicShow cpic1 = new CLocalPicShow(isp);
//        IShowPic localpic1=(IShowPic)cpic1.getProxyInstance();
//        localpic1.showPic("小图片");

        ITestInterface iti = new CTest();
        CLocalPicShow cpic2 = new CLocalPicShow(iti);
        ITestInterface localpic2=(ITestInterface)cpic2.getProxyInstance();
        localpic2.sendMessage("");

    }
}
