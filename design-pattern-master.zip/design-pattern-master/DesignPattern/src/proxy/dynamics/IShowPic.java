package proxy.dynamics;

public interface IShowPic {
    void showPic(String picName);
}
