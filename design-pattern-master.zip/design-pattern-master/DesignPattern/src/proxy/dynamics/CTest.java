package proxy.dynamics;

public class CTest implements ITestInterface{

    @Override
    public void sendMessage(String mes) {
        for(int i=5;i>=0;i--){
            System.out.println(mes+"敌军还有"+i+"秒到达战场");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.println(mes+"全军出击！！！");
    }
}
