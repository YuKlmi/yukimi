### 1. 文件系统的工厂方法模式

文件系统通过 `file_operations` 结构体定义操作接口，不同文件系统（如 `ext4`）实现各自的 `open` 方法。

#### 代码片段

**`fs/ext4/file.c`**：

c

```
const struct file_operations ext4_file_operations = {
    .open = ext4_open,    // 工厂方法：ext4 的 open 实现
    .read_iter = ext4_file_read_iter,
    .write_iter = ext4_file_write_iter,
    // 其他操作...
};
```

**`fs/ext4/file.c`**（`ext4_open` 实现）：

c

```
static int ext4_open(struct inode *inode, struct file *filp) {
    struct super_block *sb = inode->i_sb;
    // 初始化文件对象、检查合法性等...
    return generic_file_open(inode, filp);
}
```

#### UML 类图

mermaid

```
classDiagram
    class FileOperations {
        <<interface>>
        +open()
        +read()
        +write()
        +llseek()
    }

    class Ext4FileOperations {
        +open()
        +read()
        +write()
        +llseek()
    }

    class XfsFileOperations {
        +open()
        +read()
        +write()
        +llseek()
    }

    FileOperations <|.. Ext4FileOperations
    FileOperations <|.. XfsFileOperations
```

#### UML 顺序图

mermaid

```
sequenceDiagram
    participant User
    participant VFS
    participant Ext4FileOperations

    User ->> VFS: open("/mnt/ext4/file")
    VFS ->> Ext4FileOperations: open(inode, filp)
    Ext4FileOperations -->> VFS: Initialized file object
    VFS -->> User: Return file descriptor
```

------

### 2. 进程创建的原型模式

`fork` 和 `clone` 系统调用通过复制父进程的 `task_struct`（原型）创建新进程。

#### 代码片段

**`kernel/fork.c`**（核心函数）：

c

```
long _do_fork(struct kernel_clone_args *args) {
    struct task_struct *p;
    p = copy_process(NULL, args->tls, NUMA_NO_NODE, args); // 复制父进程
    wake_up_new_task(p); // 启动新进程
    return pid;
}

struct task_struct *copy_process(...) {
    struct task_struct *p;
    p = dup_task_struct(current, node); // 复制 task_struct（原型克隆）
    // 初始化子进程的寄存器、栈等...
    return p;
}
```

#### UML 类图

mermaid

```
classDiagram
    class Prototype {
        +clone()
    }

    class TaskStruct {
        -pid
        -stack
        -registers
        +clone()
    }

    Prototype <|.. TaskStruct

    class Client {
        +create_process()
    }

    Client --> Prototype: Uses clone()
```

#### UML 顺序图

mermaid

```
sequenceDiagram
    participant User
    participant Kernel
    participant copy_process
    participant dup_task_struct

    User ->> Kernel: fork()
    Kernel ->> copy_process: Create new process
    copy_process ->> dup_task_struct: Clone parent's task_struct
    dup_task_struct -->> copy_process: Cloned task_struct
    copy_process -->> Kernel: New task_struct
    Kernel -->> User: Return child PID
```

